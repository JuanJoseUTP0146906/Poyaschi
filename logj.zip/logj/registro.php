<?php

include('conexion.php');

$usu = $_POST["signupEmail"];
$pass = $_POST["signupPassword"];
$captcha = $_POST['g-recaptcha-response'];

$secret = '6LcGb3YpAAAAAFau52oRtgzTjPfwlzEg2o4PcEYn';
$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$captcha);
$response_data = json_decode($response);

if ($response_data->success) {
    $pass_md5 = md5($pass); 
    $pass_crc32 = hash("crc32", $pass_md5);
    $pass_crypt = crypt($pass_crc32, 'salt');
    $pass_sha1 = sha1($pass_crypt);

    $queryregistrar = mysqli_prepare($conn, "INSERT INTO usuarios (Usuario, Contraseña) VALUES (?, ?)");
    mysqli_stmt_bind_param($queryregistrar, "ss", $usu, $pass_sha1);
    $success = mysqli_stmt_execute($queryregistrar);

    if ($success) {
        echo "<script> alert('Usuario registrado. Inicia sesión con tus credenciales: $usu'); window.location= 'login.html' </script>";
    } else {
        echo "Error al registrar el usuario: " . mysqli_error($conn);
    }

    mysqli_stmt_close($queryregistrar);
} else {
    echo "<script> alert('Error: Por favor, verifica que eres humano.'); window.location= 'login.html' </script>";
}

mysqli_close($conn);
?>
