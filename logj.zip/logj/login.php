<?php

include('conexion.php');

$usu = $_POST["txtusuario"];
$pass = $_POST["txtpassword"];
$captcha = $_POST['g-recaptcha-response'];

$secret = '6LcGb3YpAAAAAFau52oRtgzTjPfwlzEg2o4PcEYn';
$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$captcha);
$response_data = json_decode($response);

if ($response_data->success) {
    $pass_md5 = md5($pass); 
    $pass_crc32 = hash("crc32", $pass_md5); 
    $pass_crypt = crypt($pass_crc32, 'salt'); 
    $pass_sha1 = sha1($pass_crypt); 

    $query = mysqli_prepare($conn, "SELECT Contraseña FROM Usuarios WHERE Usuario = ?");
    mysqli_stmt_bind_param($query, "s", $usu);
    mysqli_stmt_execute($query);
    mysqli_stmt_bind_result($query, $pass_sha1_stored);
    mysqli_stmt_fetch($query);

    if ($pass_sha1_stored !== null && $pass_sha1 === $pass_sha1_stored) {
        session_start();
        $_SESSION['usuario'] = $usu;
        echo "<script> alert('Bienvenido ".$usu.".');window.location= 'login.html' </script>";
    } else {
        echo "<script> alert('Usuario y/o contraseña Incorrectos no seas pendejo intenta de nuevo.');window.location= 'login.html' </script>";
    }

    mysqli_stmt_close($query);
} else {
    echo "<script> alert('Error: Por favor, verifica que eres humano.');window.location= 'login.html' </script>";
}

mysqli_close($conn);
?>
